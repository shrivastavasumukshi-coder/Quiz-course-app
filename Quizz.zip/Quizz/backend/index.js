const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;


const API_KEY = "my-secret-key";

function authMiddleware(req, res, next) {
  const key = req.headers["x-api-key"];

  if (!key || key !== API_KEY) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  next();
}


app.use(cors());
app.use(express.json());


const courses = {
  "html-course": {
    id: "html-course",
    title: "HTML Basics",
    lessons: ["lesson1", "lesson2"],
    progress: {}
  }
};
app.get("/", (req, res) => {
  res.send("Backend is running 🚀");
});


app.get("/api/quiz/html/lesson1", (req, res) => {
  res.json([
    { que: "What attribute is used to specify the URL of an image?", a: "src", b: "href", c: "link", d: "url", correct: "a" },
    { que: "Which tag is used to create a table in HTML?", a: "<table>", b: "<tr>", c: "<td>", d: "<tb>", correct: "a" },
    { que: "Which HTML element is used to define metadata?", a: "<meta>", b: "<head>", c: "<title>", d: "<body>", correct: "a" },
    { que: "Which tag is used for the largest heading?", a: "<h6>", b: "<heading>", c: "<h1>", d: "<head>", correct: "c" },
    { que: "Which HTML tag creates a line break?", a: "<lb>", b: "<break>", c: "<br>", d: "<hr>", correct: "c" }
  ]);
});

app.get("/api/quiz/html/lesson2", (req, res) => {
  res.json([
    { que: "HTML stands for?", a: "Hyper Text Markup Language", b: "High Text Machine Language", c: "Hyperlink Text Markup", d: "Home Tool Markup Language", correct: "a" },
    { que: "Which tag is used to create a hyperlink?", a: "<a>", b: "<link>", c: "<href>", d: "<url>", correct: "a" },
    { que: "Which attribute opens a link in a new tab?", a: "href", b: "target", c: "new", d: "open", correct: "b" },
    { que: "Which tag is used to insert an image?", a: "<img>", b: "<image>", c: "<src>", d: "<picture>", correct: "a" },
    { que: "Which HTML element is used to create a list item?", a: "<ul>", b: "<ol>", c: "<li>", d: "<list>", correct: "c" }
  ]);
});

app.post("/courses", authMiddleware, (req, res) => {
  const { id, title, lessons } = req.body;

  if (!id || !title || !Array.isArray(lessons)) {
    return res.status(400).json({ message: "Invalid data" });
  }

  courses[id] = {
    id,
    title,
    lessons,
    progress: {}
  };

  res.json({ message: "Course created", course: courses[id] });
});

app.get("/courses/:id", authMiddleware, (req, res) => {
  const course = courses[req.params.id];
  if (!course) {
    return res.status(404).json({ message: "Course not found" });
  }

  res.json(course);
});

app.post("/courses/:id/progress", authMiddleware, (req, res) => {
  const { userId, lessonId } = req.body;
  const course = courses[req.params.id];

  if (!course) {
    return res.status(404).json({ message: "Course not found" });
  }

  if (!userId || !lessonId) {
    return res.status(400).json({ message: "Invalid progress data" });
  }

  if (!course.progress[userId]) {
    course.progress[userId] = [];
  }

  if (!course.progress[userId].includes(lessonId)) {
    course.progress[userId].push(lessonId);
  }

  res.json({
    message: "Progress updated",
    completedLessons: course.progress[userId]
  });
});

app.get("/courses/:id/progress/:userId", authMiddleware, (req, res) => {
  const course = courses[req.params.id];

  if (!course) {
    return res.status(404).json({ message: "Course not found" });
  }

  res.json({
    userId: req.params.userId,
    completedLessons: course.progress[req.params.userId] || []
  });
});

app.post("/api/score", (req, res) => {
  console.log("Score received:", req.body);
  res.json({ message: "Score received" });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
